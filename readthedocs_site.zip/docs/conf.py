import os, sys
sys.path.append(os.path.abspath('.'))
project = 'Pronóstico de Cierre de Acción'
author = 'Equipo'
extensions = ['myst_parser']
templates_path = ['_templates']
exclude_patterns = []
html_theme = 'sphinx_rtd_theme'
